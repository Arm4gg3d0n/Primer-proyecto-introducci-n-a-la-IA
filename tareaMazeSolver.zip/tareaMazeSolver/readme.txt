Cordial Saludo profesor, se pueden ver las soluciones en consola
(incluida una visualización grafica)
ejecutando busquedas.py (Se ejecuta desde la carpete en
la que estén los mazes)  
y usando las funciones definidas:
anchura()
profundidad()
mixto()
aestrella()
se usan adecuadamente stack y queue para implementar las estructuras
de datos.
Hemos colocado el ejemplo de anchura para que pueda verlo pero permite
con todas las funciones y corre de manera adecuada. Para la parte grafica
se ejecuta el GUI.py  en caso de que haya algún inconveniente con esto último
deben estar instaladas las librerias:

<<<Para el uso de la aplicación es necesario importar las siguientes librerías:
Tkinter
Pillow
Canvas
Anytree
Math
Numpy

Luego debe seguir los números de los frames como pasos.
Para subir los archivos estos deben estar en una carpeta llamada Mazes(guardada en Desktop) o usar el cuadro de diálogo para buscar el archivo. Decide un tipo de búsqueda.>>



