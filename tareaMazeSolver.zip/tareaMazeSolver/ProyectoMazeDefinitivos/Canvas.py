from tkinter import *
import Laberinto


# funciones de dibujo/gráfica no animada
def dibujo_fondo(canvas, maze, size):
    for row in range(maze.longitud+1):
        for column in range(maze.longitud+1):
            if (row+column) % 2 == 0:
                filling = "gray"
            else:
                filling = "white"
            canvas.create_rectangle((row*size)-225, (column*size)-225,
                                    ((row+1)*size)-225, ((column+1)*size)-225, fill=filling)


def dibujo_maze(canvas, maze, size):
    for x in maze.laberinto:
        for y in x:
            if y.muro:
                canvas.create_rectangle((y.coordenadas[1]*size)-225, (y.coordenadas[0]*size)-225,
                                        ((y.coordenadas[1]+1)*size)-225, ((y.coordenadas[0]+1)*size)-225, fill="black")


def dibujo_sol(canvas, sol, size):
    for z in sol:
        coo_y = z.coordenadas[0]
        coo_x = z.coordenadas[1]
        canvas.create_rectangle((coo_x*size)-225, (coo_y*size)-225,
                                ((coo_x+1)*size)-225, ((coo_y+1)*size)-225, fill="Blue")
