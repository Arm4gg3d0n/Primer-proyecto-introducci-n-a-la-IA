# -*- coding: utf-8 -*-
"""
Created on Thu Sep 15 12:27:09 2022

@author: 57317
"""
import Laberinto
import copy
import math
import sys

class BusquedaTools():    
    def __init__(self,laberinto): 
        self.laberinto=laberinto 
        self.actual=laberinto.entrada
        #al correr profundidad se genera un self.stack
        #al correr anchura se genera un self.queue
        #al recorrer siempre se crea self.arbol
        
    def complementoCasilla(self,direccion):
        if direccion=="derecha":
            return("izquierda")
        if direccion=="izquierda":
            return("derecha")
        if direccion=="arriba":
            return("abajo")
        if direccion=="abajo":
            return("arriba")
    def siguiente(self,casilla,siguiente):  #Devuelve la casilla siguiente (casilla!= coordenadas)
        if siguiente=="derecha":
            siguiente=[casilla.coordenadas[0],casilla.coordenadas[1]+1]
        if siguiente=="izquierda":
            siguiente=[casilla.coordenadas[0],casilla.coordenadas[1]-1]
        if siguiente=="arriba":
            siguiente=[casilla.coordenadas[0]-1,casilla.coordenadas[1]]
        if siguiente=="abajo":
            siguiente=[casilla.coordenadas[0]+1,casilla.coordenadas[1]]
        return(self.laberinto.laberinto[siguiente[0]][siguiente[1]])

    def casillaDisponible(self,casilla):
          if casilla.muro==False and casilla.caminado==False:
              return(True)
          else:
              return(False)

    def ir(self,hacia): #Se debe verificar que esta casilla a la que se mueve está disponible
        auxiliar=self.siguiente(self.actual,hacia) #ojo, no puede devolverse si la casilla no esta
        if self.casillaDisponible(auxiliar): #
            self.actual.caminado=True
            self.actual.direcciones[hacia]=False
            auxiliar.direcciones[self.complementoCasilla(hacia)]=False
            auxiliar.caminado=True
            self.actual=auxiliar
            return(True)
        else:
            return(False)
    def disponibles(self,casilla):
        k=[]
        try:
            if self.laberinto.laberinto[casilla.coordenadas[0]+1][casilla.coordenadas[1]].muro==False:
                k.append(self.laberinto.laberinto[casilla.coordenadas[0]+1][casilla.coordenadas[1]])
            if self.laberinto.laberinto[casilla.coordenadas[0]-1][casilla.coordenadas[1]].muro==False:
                k.append(self.laberinto.laberinto[casilla.coordenadas[0]-1][casilla.coordenadas[1]])
            if self.laberinto.laberinto[casilla.coordenadas[0]][casilla.coordenadas[1]+1].muro==False:
                k.append(self.laberinto.laberinto[casilla.coordenadas[0]][casilla.coordenadas[1]+1])
            if self.laberinto.laberinto[casilla.coordenadas[0]][casilla.coordenadas[1]-1].muro==False:
                 k.append(self.laberinto.laberinto[casilla.coordenadas[0]][casilla.coordenadas[1]-1]) 
            return(k)
        except:
            return([])
        
    def quitarPosicion(self,casilla):
        for x in casilla.direcciones:
            casilla.direcciones[x]=True
        casilla.caminado=False
    
    def profundidad(self,n=0):
        
        self.stack=[]
        arbol=[]
        self.stack.append(self.laberinto.entrada)
        self.ir("abajo")  #primer paso que siempre es hacia abajo
        self.stack.append(self.actual) #recordemos que actual es la posicion del automata
        if n==0: #n sirve para ir hasta el final o para hacerlo parcialmente
            while self.actual.coordenadas[0]<self.laberinto.longitud:
                k=0
                for y in self.actual.direcciones:
                    if self.ir(y)==True:                
                        self.stack.append(self.actual)
                        arbol.append(self.stack.copy())                      
                        break
                    else:
                        k+=1
                    if k==4:
                        self.stack.pop()
                        self.actual=self.stack[-1]
                        arbol.append(self.stack.copy())
                       
            for z in self.stack:
                z.solucion=True
            self.HacerArbol(arbol)
            return(arbol)
        else:
            i=2 # recordemos que las primeras dos posiciones se colocan al inicio
            while i<n:
                i+=1
                k=0
                for y in self.actual.direcciones:
                    if self.ir(y)==True:                
                        self.stack.append(self.actual)
                        arbol.append(self.stack.copy())
                        break
                    else:
                        k+=1
                    if k==4:
                        self.stack.pop()
                        self.actual=self.stack[-1]
                        arbol.append(self.stack.copy())
            for z in self.stack:
                z.solucion=True
        self.HacerArbol(arbol)
        return(arbol)
 
    def anchura(self , entrada):
        # entrada= self.laberinto.entrada, 
        arbol=[]
        self.queue=[entrada] #self.queue.append(self.laberinto.entrada)        
        for t in range(self.laberinto.longitud**2):#no funciono el for x in self.queue    
            try:
                disponiblesArray=self.disponibles(self.queue[t])
                for k in disponiblesArray:
                    if k in self.queue:
                        disponiblesArray.remove(k)
                        pass
                self.queue=self.queue+disponiblesArray
                arbol.append(self.queue.copy())
                for z in disponiblesArray:
                    if z.coordenadas[0]==self.laberinto.longitud:##SAlió!!!
                        self.depurarAnchura()
                        self.HacerArbol(arbol)
                        return(arbol) #Salió del laberinto
            except:
                return(False) #NO pudo salir del laberinto         

    
    def depurarAnchura(self):  # El array de anchura tiene una solucion, este la ajusta. (self.queue)
        salida=[]
        arrayAnchura=self.queue.copy()
        salida=[arrayAnchura[0]]
        arrayAnchura.reverse()
        posicion=arrayAnchura[0]
        posicion.solucion=True
        for x in arrayAnchura:
            if abs(x.coordenadas[0]-posicion.coordenadas[0])==0 and abs(x.coordenadas[1]-posicion.coordenadas[1])==1:
                posicion=x
                salida.append(x)
            elif abs(x.coordenadas[0]-posicion.coordenadas[0])==1 and abs(x.coordenadas[1]-posicion.coordenadas[1])==0:
                posicion=x
                salida.append(x)
        for x in salida:
            x.solucion=True 
            # print(x.coordenadas,"$")
        

    def mixtoProfundidadAnchura(self,nivelProfundidad):
        #AnchuraLaberinto=deepcopy(self.laberinto)
        arbol0=self.profundidad(nivelProfundidad)
        arbol1=self.anchura(self.stack[-1])
        self.HacerArbol(arbol0+arbol1)
        return(arbol0+arbol1)
        
    def greedy(self):
        arbol=[]
        self.stack=[]
        self.stack.append(self.laberinto.entrada)
        self.ir("abajo")  #primer paso que siempre es hacia abajo
        self.stack.append(self.actual) #recordemos que actual es la posicion del automata
        while self.actual.coordenadas[0]<self.laberinto.longitud:
                k=0
                r=[]
                """Reasignamos la prioridad de direcciones de acuerdo a la
                posición de la salida del laberinto y la posicion actual del
                automata"""

                if self.actual.coordenadas[0]<self.laberinto.salida.coordenadas[0]:
                    r.append("abajo")
                if self.actual.coordenadas[0]>self.laberinto.salida.coordenadas[0]:
                    r.append("arriba")
                if self.actual.coordenadas[1]<self.laberinto.salida.coordenadas[1]:
                    r.append("derecha")
                if self.actual.coordenadas[0]>self.laberinto.salida.coordenadas[0]:
                    r.append("izquierda")
                
                """Colocamos cómo ultima prioridad los que faltararn"""
                d=["derecha","izquierda","arriba","abajo"]
                for mn in d:
                    if mn not in r:
                        r.append(mn)
                for y in r:                    
                    if self.ir(y)==True:                
                        self.stack.append(self.actual)
                        arbol.append(self.stack.copy())
                        break
                    else:
                        k+=1
                    if k==4:
                        self.stack.pop()
                        self.actual=self.stack[-1]
                        arbol.append(self.stack.copy())
        for z in self.stack:
            z.solucion=True
        self.HacerArbol(arbol)
        return(arbol)
    
    def HacerArbol(self,arbol):
        k=[]
        for x in range(1,len(arbol)):
            d=len(arbol[x-1])
            k.append(arbol[x][d:])
        self.arbol=k
    
    def euclidiano(self,x):
        return(math.sqrt(pow(x.coordenadas[0]-self.laberinto.salida.coordenadas[0],2) + pow(x.coordenadas[1]-self.laberinto.salida.coordenadas[1],2)))
    
    
    def heuristica(self,validar):        
        elegido=validar[0]
        for d in validar:
            if self.euclidiano(elegido)>self.euclidiano(d):
                elegido=d
        return(elegido)
    
    def Aestrella(self):
        current = self.laberinto.entrada
        frontier = []
        explored = []
        path = []
        splits = []
        cameFrom = []
        moveCount = 0

    #add start to frontier
        frontier.append(current)

        while len(frontier) != 0 and (self.laberinto.salida not in frontier):

            current = frontier[0]
            current.caminado=True
            valid = self.disponibles(current)
            for ddd in valid:
                if ddd.caminado==True:
                    valid.remove(ddd)
                    
            if len(valid) > 0:
                moveCount += 1
                #choose the path with least amount of distance to the goal
                chosen = self.heuristica(valid)
                frontier.append(chosen)
                explored.append(chosen)
                #avoids overriding the start symbol during printing
                if current != self.laberinto.entrada:
                    path.append(current)
                    #log each split and origin of point
                for i in valid:
                    splits.append(i)
                    cameFrom.append([i, current])
                frontier.remove(current)

            else:
                #if no more options, return to a split
                if path[-1] in splits:
                    frontier[0] = path[-1]
                    splits.remove(path[-1])
                    #backtrack down the path
                else:
                    path.remove(path[-1])
    
        self.queue=path
        self.depurarAnchura() #ESta nos sirve para encontrar entrada y salida camino
        self.laberinto.entrada.solucion=True
        self.laberinto.salida.solucion=True
