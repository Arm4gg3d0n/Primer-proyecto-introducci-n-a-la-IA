# -*- coding: utf-8 -*-
"""
Created on Tue Sep 13 20:00:42 2022

@author: 57317
"""

class Laberinto():
        
    def __init__(self,archivo): 
        self.laberinto=[]
        self.archivo=archivo
        self.cargar()
        self.Entrada_Salida() #asigna a entrada y salida las casillas correspondientes
        self.solucion=None
        self.dimension() ##asigna, self.longitud del laberinto longitud-1 #toma el cero
    class casilla():
        def __init__(self,muro): 
            self.muro=muro
            self.caminado=False
            self.solucion=False
            #self coordenadas # al cargar() se genera [x,y] que indica la posicion en la matriz
            self.direcciones={"izquierda":True,"arriba":True,"derecha":True,"abajo":True}
            
    def cargar(self):   
        try:
            fichero = open(self.archivo) #CARGAMOS LOS DATOS EN UNA MATRIZ  k
            self.k=fichero.readlines()
            fichero.close()
            for x in range(len(self.k)):
                fila=[]
                for r in self.k[x]:
                    if r=="w":
                        fila.append(self.casilla(True,))                           
                    if r=="c":
                        fila.append(self.casilla(False))
                if fila!=[]:
                    self.laberinto.append(fila)
        except:
            print("No se pudo cargar el archivo   ",self.archivo)
        dimensiones=len(self.laberinto[0]) #Colocamos coordenadas a cada cuadro del laberinto
        for x in range(dimensiones):
            for y in range(dimensiones):
                self.laberinto[x][y].coordenadas=[x,y]
    def Entrada_Salida(self): #ESTO SE HIZO PORQUE ALGUNOS LAS ENTRADAS SALIDAS DE LOS LABERINTOS PODIAN VARIAR        dimensiones=len(self.laberinto[0])
        i=0
        dimensiones=len(self.laberinto[0])-1
        while self.laberinto[0][i].muro==True:
            i+=1
        
        self.entrada=self.laberinto[0][i]
        i=0
        while self.laberinto[dimensiones][i].muro==True:
            i+=1
        self.salida=self.laberinto[dimensiones][i]
    def VerCoordenadas(self):
        for x in self.laberinto:
            for y in x:
                print(y.coordenadas,end=",")
            print("\n")
    def verLaberinto(self):
        for x in self.laberinto:
            for y in x:
                print(y.muro,end=",")
            print("\n")
    def verRecorrido(self):
        for x in self.laberinto:
            for y in x:
                if y.caminado==True:
                    print("  ** ",end=" ")
                else:
                    print(y.muro,end=",")
            print("\n")
    def verSolucion(self):
        for x in self.laberinto:
            for y in x:
                if y.solucion==True:
                    print("  ++ ",end=" ")
                else:
                    print(y.muro,end=",")
            print("\n")
    def casillaOcupada(casilla):
        for x in casilla:
            if casilla[x]==False:
                return(True)
        return(False)
    def dimension(self):
        i=0
        for x in self.laberinto[0]:
            i+=1
        self.longitud=i-1
