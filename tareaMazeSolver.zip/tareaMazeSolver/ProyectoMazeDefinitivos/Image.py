import anytree
from anytree.exporter import DotExporter

from anytree import Node, RenderTree
from PIL import Image

import graphviz
from graphviz import render

Padre = Node("[0,1]")
reco1 = Node("[1,1]", parent=Padre)
reco2 = Node("[2,1]", parent=reco1)
reco3 = Node("[3,1]", parent=reco2)
reco4 = Node("[2,2]", parent=reco2)
reco5 = Node("[2,3]", parent=reco4)
reco6 = Node("[1,3]", parent=reco5)
reco7 = Node("[3,3]", parent=reco5)
reco8 = Node("[4,3]", parent=reco7)

Node("[0,0].", parent=Padre)
Node("[0,2].", parent=Padre)

Node("[1,2].", parent=reco1)
Node("[1,0].", parent=reco1)

Node("[2,0].", parent=reco2)

Node("[3,0].", parent=reco3)
Node("[4,1].", parent=reco3)
Node("[3,2].", parent=reco3)

Node("[1,2].", parent=reco4)
Node("[3,2].", parent=reco4)

Node("[2,4].", parent=reco5)

Node("[0,3]", parent=reco6)
Node("[1,2]", parent=reco6)
Node("[1,4]", parent=reco6)

Node("[3,2]", parent=reco7)
Node("[3,4]", parent=reco7)

# print(udo)
# print(joe)
# for pre, fill, node in RenderTree(udo):
#     print("%s%s" % (pre, node.name))
DotExporter(Padre).to_picture("kha.png")


def im():
    imagen = Image.open("kha.png")
    imagen = imagen.resize((450, 500))
    imagen.save("kha.png")
    return imagen
# DotExporter(udo).to_dotfile("tree.dot")
# render('dot', 'png', 'tree.dot')
# from subprocess import check_call
# check_call(['dot', '-Tpng', 'tree.dot', '-o', 'kha.png'])
