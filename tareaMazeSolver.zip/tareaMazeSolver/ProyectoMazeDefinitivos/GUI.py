from tkinter import *
from tkinter import filedialog
from PIL import ImageTk
from PIL import Image
from Canvas import *
import turtle
import Laberinto
import busquedas
import Image

root = Tk()
root.title("Maze Solver GUI")      # Creación ventana
root.resizable(0, 0)               # Impedir reajuste dimensiones de la ventana

# Creación 4 Frames y atributos
file = LabelFrame(root, text="1. Cargar Archivo", pady=30)
file.grid(row=0, padx=1, pady=1, columnspan=3, sticky=E+W)
file.config(bg="#33F6FF")

selBt = LabelFrame(root, text="2. Seleccione un algoritmo", padx=125, pady=10)
selBt.grid(row=1, column=0, padx=1, pady=1)
selBt.config(bg="#0D58F9")

visual = LabelFrame(root, text="3. Observe el laberinto y el algoritmo", padx=5, pady=5)
visual.grid(row=1, column=1, padx=1, pady=1)
visual.config(bg="#D5E2FD")

tree = LabelFrame(root, text="4. Observe el arbol (Max 6x6)", padx=5, pady=5)
tree.grid(row=1, column=2, padx=1, pady=1)
tree.config(bg="#D18FEA")


def open_file():    # función a implementar en botón cargar archivos
    global filename, la_g, bu_g, size_blocks
    filename = filedialog.askopenfilename(initialdir="C:/Users/Asus/Desktop/Mazes",
                                          title="Selecciona un laberinto con extension CSV",
                                          filetypes=(("csv files", "*.csv"),))

    la_g = Laberinto.Laberinto(filename)
    bu_g = busquedas.BusquedaTools(la_g)
    size_blocks = 450 / (la_g.longitud + 1)
    print("open file check\n")


MazeP = []
bu_s = []


def search_prof():

    la_prof = Laberinto.Laberinto(filename)
    bu_prof = busquedas.BusquedaTools(la_prof)
    bu_prof.profundidad()

    solu = []
    for x in la_prof.laberinto:
        for y in x:
            if y.solucion:
                solu.append(y)
    global bu_s, bu_r
    bu_s = solu
    bu_r = bu_prof.arbol
    print("profundidad check\n")
    # for k in bu_prof.arbol:
    #     for r in k:
    #         print(r.coordenadas, end=" ")
    #     print("*")
    # print(bu_prof.arbol, "\n")
    # print(bu_prof.arbol[0], "\n")


def search_anc():
    print("anchura check\n")
    la_anc = Laberinto.Laberinto(filename)
    bu_anc = busquedas.BusquedaTools(la_anc)
    bu_anc.anchura(la_anc.entrada)
    bu_anc.depurarAnchura()

    solu = []
    for x in la_anc.laberinto:
        for y in x:
            if y.solucion:
                solu.append(y)
    global bu_s, bu_r
    bu_s = solu
    bu_r = bu_anc.arbol
    # for k in bu_anc.arbol:
    #     for r in k:
    #         print(r.coordenadas, end=" ")
    #     print("*")
    # print(bu_anc.arbol, "\n")
    # print(bu_anc.arbol[0], "\n")


def search_iter():
    print("iterativo check\n")
    la_iter = Laberinto.Laberinto(filename)
    bu_iter = busquedas.BusquedaTools(la_iter)
    bu_iter.mixtoProfundidadAnchura(la_iter.longitud/2)

    solu = []
    for x in la_iter.laberinto:
        for y in x:
            if y.solucion:
                solu.append(y)
    global bu_s, bu_r
    bu_s = solu
    bu_r = bu_iter.arbol


def search_cos_uni():
    print("costo uniforme check\n")
    # la_cos = Laberinto.Laberinto(filename)
    # bu_cos = busquedas.BusquedaTools(la_cos)
    # bu_cos.()

    # global bu_s
    # bu_s = bu_cos.


def search_gree():
    print("greedy check\n")
    la_gree = Laberinto.Laberinto(filename)
    bu_gree = busquedas.BusquedaTools(la_gree)
    bu_gree.greedy()

    solu = []
    for x in la_gree.laberinto:
        for y in x:
            if y.solucion:
                solu.append(y)
    global bu_s, bu_r
    bu_s = solu
    bu_r = bu_gree.arbol


def search_est():
    print("a estrella check\n")
    la_est = Laberinto.Laberinto(filename)
    bu_est = busquedas.BusquedaTools(la_est)
    bu_est.Aestrella()

    solu = []
    for x in la_est.laberinto:
        for y in x:
            if y.solucion:
                solu.append(y)
    global bu_s, bu_r
    bu_s = solu
    #bu_r = bu_est.
    # frontier
    # explored
    # path
    # bu_r = bu_est.arbol


# ejemplos a usar para gráfica

reco5x5 = [[0, 1], [1, 1], [2, 1], [3, 1], [2, 2], [2, 3], [3, 3], [4, 3]]

reco10x10 = [[0, 3], [1, 3], [2, 3], [2, 2], [3, 2],
             [3, 1], [4, 1], [5, 1], [6, 1], [7, 1], [8, 1], [5, 2], [5, 3],
             [5, 4], [4, 4], [4, 5], [4, 6], [5, 6],
             [5, 7], [6, 7], [7, 7], [8, 7], [8, 8],
             [9, 8]]

recoE = reco5x5

# creación botones
btnFile = Button(file, text="Abre el archivo csv del laberinto", command=open_file)
btnFile.pack()


btnP = Button(selBt, text="Búsqueda Profundidad", bg="#65337B", fg="#FFA016", command=search_prof)
btnP.grid(column=0, row=0, pady=30)

btnA = Button(selBt, text="Búsqueda Anchura", bg="#65337B", fg="#FFA016", command=search_anc)
btnA.grid(column=0, row=1, pady=30)

btnI = Button(selBt, text="Búsqueda Iterativa", bg="#65337B", fg="#FFA016", command=search_iter)
btnI.grid(column=0, row=2, pady=30)

btnCU = Button(selBt, text="Búsqueda Costo Uniforme", bg="#65337B", fg="#FFA016", command=search_cos_uni)
btnCU.grid(column=0, row=3, pady=30)

btnG = Button(selBt, text="Búsqueda Greedy", bg="#65337B", fg="#FFA016", command=search_gree)
btnG.grid(column=0, row=4, pady=30)

btnE = Button(selBt, text="Búsqueda A estrella", bg="#65337B", fg="#FFA016", command=search_est)
btnE.grid(column=0, row=5, pady=30)

# creación canvas
canvasM = Canvas(visual, width=450, height=500, bg='white')
canvasM.grid(column=0, row=0, pady=5)


# función del botón iniciar gráfica
def iniciar_canvas():
    dibujo_fondo(canvasM, la_g, size_blocks)
    dibujo_maze(canvasM, la_g, size_blocks)
    # recorrido(la_g, bu_r, size_blocks)
    dibujo_sol(canvasM, bu_s, size_blocks)


btnMaze = Button(visual, text="Iniciar maze", command=iniciar_canvas)
btnMaze.grid(column=0, row=1, pady=5)


def dibujo_arbol():
    print("arbol\n")
    if la_g.longitud+1 <= 6:
        print("arbol viable\n")
        im = Image.im()
        img = ImageTk.PhotoImage(im)
        panel = Label(tree, image=img)
        # panel.pack()
        panel.grid(column=0, row=1)
    else:
        print("arbol no viable\n")


btnArbol = Button(tree, text="Arbol", command=dibujo_arbol)
btnArbol.grid(column=0, row=0, pady=5)
# btnArbol.pack()


# canvasArbol = Canvas(tree, width=450, height=500, bg='#8298C6')
# canvasArbol.grid(column=0, row=1)

# elementos para animación
turtle_screen = turtle.TurtleScreen(canvasM)
turtle_screen.mode("logo")
t = turtle.RawTurtle(turtle_screen)
t.hideturtle()
t.speed(0)


def recorrido(maze, reco, size):
    t.goto((maze.entrada.coordenadas[1]*size - 225, -maze.entrada.coordenadas[0]*size + 225 - size))
    t.fillcolor("Yellow")
    t.begin_fill()
    for i in range(4):
        t.forward(size)
        t.right(90)
    t.end_fill()
    t.penup()
    t.goto((maze.entrada.coordenadas[1]*size - 225, (-maze.entrada.coordenadas[0]-1)*size + 225 - size))
    t.pendown()
    t.fillcolor("Yellow")
    t.begin_fill()
    for i in range(4):
        t.forward(size)
        t.right(90)
    t.end_fill()
    for rama in reco:
        for coo in rama:
            coo_y = coo.coordenadas[0] * size
            coo_x = coo.coordenadas[1] * size
            t.penup()
            t.goto((coo_x - 225, -coo_y + 225 - size))
            t.pendown()
            t.fillcolor("Yellow")
            t.begin_fill()
            for i in range(4):
                t.forward(size)
                t.right(90)
            t.end_fill()


root.mainloop()
